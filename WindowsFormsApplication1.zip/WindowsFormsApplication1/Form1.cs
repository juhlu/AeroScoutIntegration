﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*
            Event Type: Call Button,
            Event name: Duress,
            Event ID: 320022,
            Asset ID: 004,
            Asset name: Doctor Two,
            Asset status: N / A,
            Location description: Asset's location,
            Area map: Lab,
            Zones: Lab,
            Date: 25 / 07 / 16 2:44:01 PM,
            Tag message: N / A,
            Alert message: Staff Duress Alarm.

            Sent by MobileView.
            */
//            string message = string.Format("Event Type"); // textBoxAssetId.Text, textBoxAssetName.Text);

            string message = string.Format("Event Type:Call Button,Asset ID: {0},Asset name:{1},Area map:{2},Zones:{3},Date:{4}, Sent by MobileView.",
    textBoxAssetId.Text, textBoxAssetName.Text, textBoxAreaMap.Text, textBoxZone.Text, DateTime.UtcNow);


            HttpPost(textBoxURI.Text, message);
        }

        public static string HttpPost(string URI, string Parameters)
        {
            System.Net.WebRequest req = System.Net.WebRequest.Create(URI);
            req.Proxy = new System.Net.WebProxy(URI, true);
            //Add these, as we're doing a POST
            req.ContentType = "application/x-www-form-urlencoded";
            req.Method = "POST";
            //We need to count how many bytes we're sending. 
            //Post'ed Faked Forms should be name=value&
            byte[] bytes = System.Text.Encoding.ASCII.GetBytes(Parameters);
            req.ContentLength = bytes.Length;
            System.IO.Stream os = req.GetRequestStream();
            os.Write(bytes, 0, bytes.Length); //Push it out there
            os.Close();
            System.Net.WebResponse resp = req.GetResponse();
            if (resp == null) return null;
            System.IO.StreamReader sr =
                  new System.IO.StreamReader(resp.GetResponseStream());
            return sr.ReadToEnd().Trim();
        }
    }
}
