﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxAssetName = new System.Windows.Forms.TextBox();
            this.textBoxAreaMap = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxZone = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxURI = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxAssetId = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBoxAssetName
            // 
            this.textBoxAssetName.Location = new System.Drawing.Point(106, 26);
            this.textBoxAssetName.Name = "textBoxAssetName";
            this.textBoxAssetName.Size = new System.Drawing.Size(100, 20);
            this.textBoxAssetName.TabIndex = 0;
            this.textBoxAssetName.Text = "Patient 1";
            // 
            // textBoxAreaMap
            // 
            this.textBoxAreaMap.Location = new System.Drawing.Point(106, 63);
            this.textBoxAreaMap.Name = "textBoxAreaMap";
            this.textBoxAreaMap.Size = new System.Drawing.Size(100, 20);
            this.textBoxAreaMap.TabIndex = 1;
            this.textBoxAreaMap.Text = "Lab1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Asset Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Area Map";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Zone";
            // 
            // textBoxZone
            // 
            this.textBoxZone.Location = new System.Drawing.Point(106, 107);
            this.textBoxZone.Name = "textBoxZone";
            this.textBoxZone.Size = new System.Drawing.Size(100, 20);
            this.textBoxZone.TabIndex = 5;
            this.textBoxZone.Text = "Bed1";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(174, 234);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Send";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "URI";
            // 
            // textBoxURI
            // 
            this.textBoxURI.Location = new System.Drawing.Point(106, 185);
            this.textBoxURI.Name = "textBoxURI";
            this.textBoxURI.Size = new System.Drawing.Size(288, 20);
            this.textBoxURI.TabIndex = 8;
            this.textBoxURI.Text = "http://localhost:8080";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(32, 153);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Asset ID";
            // 
            // textBoxAssetId
            // 
            this.textBoxAssetId.Location = new System.Drawing.Point(106, 146);
            this.textBoxAssetId.Name = "textBoxAssetId";
            this.textBoxAssetId.Size = new System.Drawing.Size(100, 20);
            this.textBoxAssetId.TabIndex = 9;
            this.textBoxAssetId.Text = "123";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(425, 284);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxAssetId);
            this.Controls.Add(this.textBoxURI);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBoxZone);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxAreaMap);
            this.Controls.Add(this.textBoxAssetName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxAssetName;
        private System.Windows.Forms.TextBox textBoxAreaMap;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxZone;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxURI;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxAssetId;
    }
}

